  var resultado = document.getElementById('display');
  var reset     = document.getElementById('on');
  var signo     = document.getElementById('sign');
  var raiz      = document.getElementById('raiz');
  var dividido  = document.getElementById('dividido');
  var siete     = document.getElementById('7');
  var ocho      = document.getElementById('8');
  var nueve     = document.getElementById('9');
  var por       = document.getElementById('por');
  var cuatro    = document.getElementById('4');
  var cinco     = document.getElementById('5');
  var seis      = document.getElementById('6');
  var menos     = document.getElementById('menos');
  var uno       = document.getElementById('1');
  var dos       = document.getElementById('2');
  var tres      = document.getElementById('3');
  var cero      = document.getElementById('0');
  var punto     = document.getElementById('punto');
  var igual     = document.getElementById('igual');
  var mas       = document.getElementById('mas');
  
  var calculadora = {
    operando : "0",
    resultado : 0,
    operador : '0',
    op1 : 0,
    op2 : 0,
    

    setOperando:function(digito){
      if(this.operando == "0"){
        if(digito != '-'){
          this.operando = digito;
        }
      }else{
        switch (digito) {
          case ".":
              if (this.operando.indexOf(".") == -1){
                this.operando = this.operando + ".";
              }
              break;

          case "-":
              if(this.operando.indexOf("-") == -1){
                this.operando = digito + this.operando;
              } else {
                this.operando = this.operando.replace('-','');
              }
              break;

          default:
            this.operando = this.operando + digito;
        }
      }
     },

    borra:function() {
      this.operando  = '0';
      this.resultado = 0;
      this.op1=0;
      this.op2=0;
      this.operador  = '0';
    },

    operar:function(op){
    	 switch(this.operador){       	 	
            case '+':
              this.op2 = parseInt(this.operando,10);
              this.resultado = this.op1 + this.op2;
              this.operador = op;
              this.op1 = this.resultado;
              this.operando='0';
              break;
            case '-':
              this.op2 = parseInt(this.operando,10);
              this.operando='0';
              this.resultado = this.op1 - this.op2;
              this.operador = op;
              this.op1 = this.resultado;
              break;
            case '/':
              this.op2 = parseInt(this.operando,10);
              this.operando='0';
              this.resultado = this.op1 / this.op2;
              this.operador = op;
              this.op1 = this.resultado;
              break;
            case '*':
              this.op2 = parseInt(this.operando,10);
              this.operando='0';
              this.resultado = this.op1 * this.op2;
              this.operador = op;
              this.op1 = this.resultado;
              break;
             case 'S':
              this.op1 = this.operando;
              this.resultado = Math.sqrt(this.op1);
              this.operando='0';                          
              break;
            case '0':
              this.operador = op;
              if (this.op1 == 0)
              	 this.op1 = parseInt(this.operando,10);
              else
               	 this.op2 = parseInt(this.operando,10);
              this.operando = 0;	
            }
        },

    getResultado:function(){
       return this.resultado.toString().substr(0,9);
    },

    getOperando:function(){
      return this.operando.substr(0,9);
    }


  };

  function actualizaDisplay(opcion){
    if(opcion == 0){
      resultado.innerHTML = calculadora.getOperando();
    } else {
      resultado.innerHTML = calculadora.getResultado();
    }
  }
  
  raiz.addEventListener('click', function(){
  	  calculadora.operador='S';
  	  calculadora.operar('0');
      actualizaDisplay(1);
  });
  
  dividido.addEventListener('click', function(){
  	  calculadora.operar('/');
      actualizaDisplay(1);
  });

  mas.addEventListener('click', function(){
  	  calculadora.operar('+');
      actualizaDisplay(1);
  });

  menos.addEventListener('click', function(){
      calculadora.operar('-');
      actualizaDisplay(1);
  });

  por.addEventListener('click', function(){
      calculadora.operar('*');
      actualizaDisplay(1);
  });

  igual.addEventListener('click', function(){
  	  calculadora.operar(calculadora.operador);
  	  calculadora.op1 = calculadora.resultado;
      actualizaDisplay(1);
  });

  reset.addEventListener('click', function(){
    calculadora.borra();
    actualizaDisplay(0);
  });

  uno.addEventListener('click', function(){
    calculadora.setOperando('1');
    actualizaDisplay(0);
  });

  dos.addEventListener('click', function(){
    calculadora.setOperando('2');
    actualizaDisplay(0);
  });

  tres.addEventListener('click', function(){
    calculadora.setOperando('3');
    actualizaDisplay(0);
  });

  cuatro.addEventListener('click', function(){
    calculadora.setOperando('4');
    actualizaDisplay(0);
  });

  cinco.addEventListener('click', function(){
    calculadora.setOperando('5');
    actualizaDisplay(0);
  });

  seis.addEventListener('click', function(){
    calculadora.setOperando('6');
    actualizaDisplay(0);
  });

  siete.addEventListener('click', function(){
    calculadora.setOperando('7');
    actualizaDisplay(0);
  });

  ocho.addEventListener('click', function(){
    calculadora.setOperando('8');
    actualizaDisplay(0);
  });

  nueve.addEventListener('click', function(){
    calculadora.setOperando('9');
    actualizaDisplay(0);
  });

  cero.addEventListener('click', function(){
    calculadora.setOperando('0');
    actualizaDisplay(0);
  });

  punto.addEventListener('click', function(){
    calculadora.setOperando('.');
    actualizaDisplay(0);
  });

  signo.addEventListener('click', function(){
    calculadora.setOperando('-');
    actualizaDisplay(0);
  });
